/**
 * This package defines extensible service interfaces.
 *
 * @author Maik Scheibler
 */
package org.eclipse.paho.client.mqttv3.spi;